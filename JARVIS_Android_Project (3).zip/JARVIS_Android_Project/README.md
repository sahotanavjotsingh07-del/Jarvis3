# JARVIS Android AI Assistant

A phone-friendly installable web app (PWA) with:
- Online chat using the Gemini API through a private server-side key.
- Offline built-in tools: greetings, date, time and simple arithmetic.
- Text chat, browser speech input, and spoken replies where supported.
- An offline-cached app shell.

## Important limits
- Offline mode is **not a full offline language model**. It provides a small set of built-in commands and calculations.
- Android Chrome speech recognition may use an online service and may not work without internet. Text input works offline; speech output depends on voices installed on the phone.
- Online AI requires internet and a Gemini API key. A parent/guardian should handle account setup and review any billing or usage terms. Free quotas and model availability can change.
- Keep `GEMINI_API_KEY` private. Never paste it into `public/index.html`, GitHub, chat messages, or screenshots.

## Deploy using only an Android phone

### A. Upload the ZIP to your existing GitHub repository
1. Keep this ZIP file on your phone. Open your existing GitHub repository named **Jarvis** in Chrome and sign in.
2. Tap **Add file** > **Upload files** and select `JARVIS_Android_Project.zip`.
3. Tap **Commit changes**. Upload the ZIP itself; do not upload any API key or `.env` file.

### B. Deploy it on Render
1. With a parent/guardian's help, open Render in Chrome and sign in.
2. Choose **New** > **Web Service**, connect your GitHub account, and select the **Jarvis** repository.
3. Set Runtime to **Node**.
4. Set Build Command to:
   `unzip -o JARVIS_Android_Project.zip -d . && cd JARVIS_Android_Project && npm install`
5. Set Start Command to:
   `cd JARVIS_Android_Project && npm start`
6. Choose the available **Free** instance if offered, then create the service.
7. In the service's **Environment** settings, add `GEMINI_API_KEY` with the private key created in Google AI Studio by the parent/guardian. Optionally add `GEMINI_MODEL` = `gemini-2.5-flash`.
8. Save changes and wait for deployment to finish. Copy the HTTPS service URL.

### C. Install JARVIS on Android
1. Open the HTTPS service URL in Chrome on your phone.
2. Wait for the page to load once while online.
3. Open Chrome menu (⋮) > **Add to Home screen** or **Install app**.
4. Open JARVIS from the new home-screen icon.
5. Choose **Online AI** when connected; choose **Offline tools** without internet.

## Troubleshooting
- **Online AI key not configured:** check the Render environment variable spelling is exactly `GEMINI_API_KEY`, then redeploy/restart.
- **Online AI cannot reply:** check the key, model availability, usage limits and internet. Do not share the key.
- **App opens but AI is offline:** a free host may pause an inactive service. Open the site and wait for it to wake.
- **Microphone doesn't work:** allow microphone permission for the site; use Chrome; if speech recognition is unsupported, type instead.
- **Offline page does not open:** load the site once online first. The cached shell can open offline, but the server and online AI cannot.

## Local development
Requires Node.js 20+. Run `npm install`, set `GEMINI_API_KEY` in a private `.env` file, then `npm start`.
