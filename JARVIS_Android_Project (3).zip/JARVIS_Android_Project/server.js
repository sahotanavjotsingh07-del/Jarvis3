import "dotenv/config";
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const port = Number(process.env.PORT || 3000);
const here = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "64kb" }));
app.use(express.static(path.join(here, "public")));

app.get("/api/status", (_req, res) => {
  res.json({ onlineAIReady: Boolean(process.env.GEMINI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(503).json({
    error: "Online AI is not set up yet. Ask a parent or trusted adult to configure the private API key. Offline mode still works."
  });

  const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
  const safe = messages
    .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
    .slice(-12)
    .map(m => `${m.role === "user" ? "User" : "JARVIS"}: ${m.content.slice(0, 2500)}`);

  if (!safe.length || !messages.length || messages[messages.length - 1]?.role !== "user") {
    return res.status(400).json({ error: "Type a message first." });
  }

  const prompt = [
    "You are JARVIS, a helpful, friendly personal assistant.",
    "Use clear, age-appropriate language. Explain school topics simply.",
    "Never claim you performed actions, accessed accounts, or controlled devices unless an actual tool did so.",
    "Do not ask for passwords, payment information, home address, or other sensitive personal data.",
    "Conversation:",
    safe.join("\n")
  ].join("\n\n");

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${process.env.GEMINI_MODEL || "gemini-2.5-flash"}:generateContent`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: prompt }] }] })
      }
    );
    const data = await response.json();
    if (!response.ok) {
      console.error("Gemini API returned", response.status);
      return res.status(502).json({ error: "Online AI could not reply. Check the private API setup or try again later." });
    }
    const reply = data?.candidates?.[0]?.content?.parts
      ?.map(part => part.text || "").join("").trim();
    res.json({ reply: reply || "I couldn't make a reply. Please try again." });
  } catch (err) {
    console.error("Online AI request failed:", err?.message || err);
    res.status(502).json({ error: "Could not reach online AI. Check your internet connection." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(here, "public", "index.html")));

app.listen(port, () => console.log(`JARVIS server listening on ${port}`));
